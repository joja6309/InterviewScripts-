programming exercise:

Theoretical situation:
We have data coming from a security device that outputs json. We need to monitor a folder for new files and process them as as soon as possible.
The output should be a status of the system with statistics every second. For the purpose of this exercise write code that you would feel comfortable
deploying in a high performance environment.

Example:

Input:
{"Type":Door, "Date":"2014-02-01 10:01:02", "open": true}
--new file
{"Type":Alarm, "Date":"2014-02-01 10:01:01", "name":"fire", "floor":"1", "Room": "101"}

Output:
"EventCnt: 1, ImgCnt:0, AlarmCnt:0, avgProcessingTime: 10ms"


Some example input files should be attached.
