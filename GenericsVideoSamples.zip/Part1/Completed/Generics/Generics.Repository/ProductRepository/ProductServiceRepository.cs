﻿using System;
using System.Collections.Generic;
using Generics.Common;
using Generics.Common.Interface;

namespace Generics.Repository.ProductRepository
{
    public class ProductServiceRepository
    {

    }
}
