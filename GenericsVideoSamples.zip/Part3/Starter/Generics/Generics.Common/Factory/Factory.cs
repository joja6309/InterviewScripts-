﻿using System;
using System.Configuration;

namespace Generics.Common.Factory
{
    public static class Factory
    {

    }
}
